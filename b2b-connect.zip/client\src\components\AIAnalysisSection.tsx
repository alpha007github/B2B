import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { BrainCircuit, Activity, Sparkles, ArrowRight, Check } from "lucide-react";

type AnalysisForm = {
  monthlyCost: string;
  simCount: string;
  contractAge: string;
  deviceCosts: string;
  addOns: string;
  frameworkContract: string;
  requirements: string;
};

type AnalysisScenario = {
  lowMonthlySavings: number;
  expectedMonthlySavings: number;
  highMonthlySavings: number;
  yearlyLowSavings: number;
  yearlyExpectedSavings: number;
  yearlyHighSavings: number;
  lowRate: number;
  expectedRate: number;
  highRate: number;
  dataCompleteness: number;
};

type AnalysisPhase = {
  code: string;
  title: string;
  description: string;
  steps: number[];
  stepDurationMs: number;
};

const ANALYSIS_PHASES: AnalysisPhase[] = [
  {
    code: "Phase A",
    title: "Infrastruktur-Abgleich",
    description: "Abgleich Ihrer aktuellen Tarife und Preise mit dem unabhängigen Markt.",
    steps: [10, 25, 39, 100],
    stepDurationMs: 520,
  },
  {
    code: "Phase B",
    title: "Struktur-Optimierung",
    description: "Identifikation von Ineffizienzen und ungenutzten Potenzialen.",
    steps: [12, 34, 61, 100],
    stepDurationMs: 560,
  },
  {
    code: "Phase C",
    title: "Potenzial-Vorschau",
    description: "Berechnung der wirtschaftlichen und technischen Optimierungschancen.",
    steps: [17, 46, 73, 100],
    stepDurationMs: 610,
  },
];

export default function AIAnalysisSection() {
  const [form, setForm] = useState<AnalysisForm>({
    monthlyCost: "8000",
    simCount: "120",
    contractAge: "18",
    deviceCosts: "Teilweise",
    addOns: "International + Datenboost",
    frameworkContract: "Ja",
    requirements: "Fokus auf bundesweite Feldteams und stabile Erreichbarkeit bei Roaming.",
  });

  const [analysisState, setAnalysisState] = useState<"idle" | "running" | "done">("idle");
  const [activePhaseIndex, setActivePhaseIndex] = useState<number | null>(null);
  const [visibleStepCounts, setVisibleStepCounts] = useState<number[]>([0, 0, 0]);
  const [displayedScenario, setDisplayedScenario] = useState<AnalysisScenario | null>(null);

  const resultRef = useRef<HTMLDivElement>(null);

  const handleStartAnalysis = () => {
    if (analysisState === "running") return;

    setAnalysisState("running");
    setDisplayedScenario(null);
    setActivePhaseIndex(0);
    setVisibleStepCounts([0, 0, 0]);

    let elapsedMs = 0;
    const nextScenario = calculateScenario(form);

    ANALYSIS_PHASES.forEach((phase, phaseIndex) => {
      phase.steps.forEach((_, stepIndex) => {
        elapsedMs += phase.stepDurationMs;
        setTimeout(() => {
          setActivePhaseIndex(phaseIndex);
          setVisibleStepCounts((prev) => {
            const next = [...prev];
            next[phaseIndex] = stepIndex + 1;
            // Mark previous phases as complete
            for (let i = 0; i < phaseIndex; i++) {
              next[i] = ANALYSIS_PHASES[i].steps.length;
            }
            return next;
          });
        }, elapsedMs);
      });
    });

    setTimeout(() => {
      setDisplayedScenario(nextScenario);
      setAnalysisState("done");
      setActivePhaseIndex(ANALYSIS_PHASES.length - 1);
      setVisibleStepCounts(ANALYSIS_PHASES.map((p) => p.steps.length));
      
      // Scroll to results
      resultRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, elapsedMs + 200);
  };

  const updateField = (key: keyof AnalysisForm, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const overallProgress = Math.round(
    (visibleStepCounts.reduce((a, b) => a + b, 0) /
      ANALYSIS_PHASES.reduce((a, b) => a + b.steps.length, 0)) *
      100
  );

  return (
    <section id="ki-rechner" className="py-24 bg-[#faf8f5]">
      <div className="container">
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-8 h-[1px] bg-stone/40" />
            <span className="text-[11px] font-medium tracking-[0.2em] uppercase text-stone/60">
              KI-Kommunikationsanalyse
            </span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl text-charcoal mb-6">
            Präzise. Unabhängig. KI-gestützt.
            <br />
            <span className="text-stone-light">Klarheit vor Entscheidung.</span>
          </h2>
          <p className="text-lg text-stone leading-relaxed font-light">
            Kein Bauchgefühl. Keine Annahmen. Nur Daten. Unsere KI-gestützte Analyse verdichtet Ihre aktuelle Kommunikationsinfrastruktur zu einer belastbaren Entscheidungsgrundlage.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left: Form */}
          <div className="lg:col-span-7 space-y-8">
            <div className="bg-white border border-[#e8e2d8] p-8 md:p-10 shadow-sm">
              <div className="flex items-center gap-2 mb-8">
                <div className="w-1.5 h-1.5 rounded-full bg-charcoal" />
                <span className="text-[11px] font-semibold uppercase tracking-widest text-charcoal/60">
                  Eingabematrix
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InputField
                  label="Monatliche Mobilfunkkosten (EUR)"
                  value={form.monthlyCost}
                  onChange={(v) => updateField("monthlyCost", v)}
                  type="number"
                  disabled={analysisState === "running"}
                />
                <InputField
                  label="Anzahl der SIM-Karten"
                  value={form.simCount}
                  onChange={(v) => updateField("simCount", v)}
                  type="number"
                  disabled={analysisState === "running"}
                />
                <InputField
                  label="Durchschnittliches Vertragsalter (Monate)"
                  value={form.contractAge}
                  onChange={(v) => updateField("contractAge", v)}
                  type="number"
                  disabled={analysisState === "running"}
                />
                <SelectField
                  label="Sind Gerätekosten enthalten?"
                  value={form.deviceCosts}
                  options={["Nein", "Teilweise", "Ja"]}
                  onChange={(v) => updateField("deviceCosts", v)}
                  disabled={analysisState === "running"}
                />
                <InputField
                  label="Optionen / Zusatzpakete"
                  value={form.addOns}
                  onChange={(v) => updateField("addOns", v)}
                  type="text"
                  disabled={analysisState === "running"}
                />
                <SelectField
                  label="Ist ein Rahmenvertrag vorhanden?"
                  value={form.frameworkContract}
                  options={["Nein", "Ja"]}
                  onChange={(v) => updateField("frameworkContract", v)}
                  disabled={analysisState === "running"}
                />
                <div className="md:col-span-2">
                  <label className="block text-[13px] font-medium text-charcoal/70 mb-2 uppercase tracking-wide">
                    Besondere Anforderungen
                  </label>
                  <textarea
                    rows={3}
                    value={form.requirements}
                    onChange={(e) => updateField("requirements", e.target.value)}
                    disabled={analysisState === "running"}
                    className="w-full bg-[#faf8f5] border border-sand-dark/30 p-4 text-sm text-charcoal outline-none focus:border-stone/50 transition-colors resize-none"
                  />
                </div>
              </div>

              <button
                onClick={handleStartAnalysis}
                disabled={analysisState === "running"}
                className="mt-10 w-full group flex items-center justify-between bg-[#2c2520] text-white p-6 transition-all hover:bg-[#3a3228] disabled:opacity-70 disabled:cursor-not-allowed"
              >
                <div className="text-left">
                  <p className="text-[13px] font-semibold tracking-[0.1em] uppercase mb-1">
                    {analysisState === "running" ? "Analyse läuft..." : "KI-Analyse starten"}
                  </p>
                  <p className="text-[11px] text-white/60 font-light">
                    {analysisState === "running" 
                      ? "Ihre Daten werden verarbeitet" 
                      : "Berechnung der Optimierungspotenziale"}
                  </p>
                </div>
                <div className="flex items-center gap-3 bg-white/10 px-4 py-2 rounded-sm">
                  {analysisState === "running" ? (
                    <Activity className="w-4 h-4 animate-pulse" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  <span className="text-[11px] font-bold uppercase tracking-widest">
                    {analysisState === "running" ? "Läuft" : "Start"}
                  </span>
                </div>
              </button>
            </div>
          </div>

          {/* Right: Status & Results */}
          <div className="lg:col-span-5 space-y-6">
            {/* Phase Status Panel */}
            <div className="bg-[#2c2520] p-8 text-white shadow-lg border border-white/5">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#d4c9a8]">
                    KI-gestützte Analyse
                  </p>
                  <p className="text-xs text-white/40 mt-1">Schrittweise Auswertung</p>
                </div>
                <div className={`w-2 h-2 rounded-full ${analysisState === "running" ? "bg-[#d4c9a8] animate-pulse shadow-[0_0_10px_#d4c9a8]" : "bg-white/10"}`} />
              </div>

              <div className="space-y-4">
                {ANALYSIS_PHASES.map((phase, idx) => {
                  const isDone = analysisState === "done" || (activePhaseIndex !== null && idx < activePhaseIndex);
                  const isActive = activePhaseIndex === idx && analysisState === "running";
                  const progress = isDone ? 100 : isActive ? phase.steps[Math.min(visibleStepCounts[idx] - 1, phase.steps.length - 1)] || 0 : 0;

                  return (
                    <div 
                      key={phase.code}
                      className={`p-4 border transition-colors duration-300 ${
                        isActive ? "border-[#d4c9a8]/50 bg-white/5" : isDone ? "border-white/10 bg-white/5" : "border-white/5 bg-transparent"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full ${isDone ? "bg-[#d4c9a8]" : isActive ? "bg-white" : "bg-white/20"}`} />
                            <span className="text-[10px] font-medium uppercase tracking-widest text-white/40">{phase.code}</span>
                          </div>
                          <p className="text-sm font-medium">{phase.title}</p>
                          <p className="text-[11px] text-white/40 leading-relaxed">{phase.description}</p>
                        </div>
                        <div className="flex flex-col items-end gap-2 min-w-[60px]">
                          <span className="text-[10px] font-bold uppercase tracking-tighter text-[#d4c9a8]">
                            {isDone ? "Fertig" : isActive ? "Läuft" : "Bereit"}
                          </span>
                          <div className="text-lg font-display text-white/90">{progress}%</div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Overall Progress */}
              <div className="mt-8 pt-8 border-t border-white/10">
                <div className="flex justify-between items-end mb-3">
                  <span className="text-[11px] font-semibold uppercase tracking-widest text-white/40">Gesamtfortschritt</span>
                  <span className="text-xl font-display text-[#d4c9a8]">{overallProgress}%</span>
                </div>
                <div className="h-1 bg-white/10 overflow-hidden">
                  <motion.div 
                    className="h-full bg-[#d4c9a8]"
                    initial={{ width: 0 }}
                    animate={{ width: `${overallProgress}%` }}
                  />
                </div>
              </div>
            </div>

            {/* Result Preview (Only if done or running) */}
            <div 
              ref={resultRef}
              className={`transition-all duration-500 ${analysisState === "idle" ? "opacity-40 grayscale pointer-events-none" : "opacity-100"}`}
            >
              <div className="bg-white border border-[#e8e2d8] p-8 shadow-sm">
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="w-4 h-4 text-stone" />
                  <span className="text-[11px] font-semibold uppercase tracking-widest text-charcoal/60">
                    Ergebnisvorschau
                  </span>
                </div>

                {analysisState === "running" ? (
                  <div className="py-12 text-center space-y-4">
                    <Activity className="w-8 h-8 text-stone/40 mx-auto animate-spin" />
                    <p className="text-sm text-stone font-light italic">Analyse wird durchgeführt...</p>
                  </div>
                ) : displayedScenario ? (
                  <div className="space-y-6">
                    <div className="p-6 bg-[#faf8f5] border border-sand-dark/20">
                      <p className="text-[11px] font-semibold uppercase tracking-widest text-stone/60 mb-2">Monatliches Potenzial</p>
                      <p className="text-3xl font-display text-charcoal">
                        {formatCurrency(displayedScenario.lowMonthlySavings)} – {formatCurrency(displayedScenario.highMonthlySavings)}
                      </p>
                      <p className="text-xs text-stone mt-2">
                        Erwarteter Mittelwert: <span className="font-bold text-charcoal">{formatCurrency(displayedScenario.expectedMonthlySavings)}</span>
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 border border-sand-dark/20">
                        <p className="text-[10px] font-semibold uppercase tracking-widest text-stone/60 mb-1">Jährlich</p>
                        <p className="text-lg font-display text-charcoal">{formatCurrency(displayedScenario.yearlyExpectedSavings)}</p>
                      </div>
                      <div className="p-4 border border-sand-dark/20">
                        <p className="text-[10px] font-semibold uppercase tracking-widest text-stone/60 mb-1">Quote</p>
                        <p className="text-lg font-display text-charcoal">{formatPercent(displayedScenario.expectedRate)}</p>
                      </div>
                    </div>

                    <div className="pt-6">
                      <a 
                        href="#kontakt"
                        className="flex items-center justify-center gap-3 w-full py-4 bg-[#2c2520] text-white text-[12px] font-semibold tracking-widest uppercase hover:bg-[#3a3228] transition-colors"
                      >
                        Detaillierte Analyse anfragen
                        <ArrowRight className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                ) : (
                  <div className="py-12 text-center">
                    <p className="text-sm text-stone/40 font-light">Starten Sie die Analyse für eine Vorschau.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function InputField({ label, value, onChange, type, disabled }: { label: string; value: string; onChange: (v: string) => void; type: string; disabled: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-semibold text-charcoal/50 mb-2 uppercase tracking-[0.1em]">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="w-full h-12 bg-[#faf8f5] border border-[#e8e2d8] px-4 text-sm text-charcoal outline-none focus:border-[#b5a88e] transition-colors disabled:opacity-50"
      />
    </div>
  );
}

function SelectField({ label, value, options, onChange, disabled }: { label: string; value: string; options: string[]; onChange: (v: string) => void; disabled: boolean }) {
  return (
    <div>
      <label className="block text-[11px] font-semibold text-charcoal/50 mb-2 uppercase tracking-[0.1em]">
        {label}
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="w-full h-12 bg-[#faf8f5] border border-[#e8e2d8] px-4 text-sm text-charcoal outline-none focus:border-[#b5a88e] transition-colors disabled:opacity-50"
      >
        {options.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
    </div>
  );
}

// --- Logic Helpers ---

function calculateScenario(form: AnalysisForm): AnalysisScenario {
  const monthlyCost = Math.max(0, parseFloat(form.monthlyCost.replace(",", ".")) || 0);
  const simCount = Math.max(1, parseFloat(form.simCount.replace(",", ".")) || 1);
  const contractAge = Math.max(0, parseFloat(form.contractAge.replace(",", ".")) || 0);
  const avgCostPerSim = monthlyCost / simCount;

  const mappedDeviceState = mapDeviceState(form.deviceCosts);
  const mappedAddOnIntensity = mapAddOnIntensity(form.addOns);
  const mappedFrameworkState = mapYesNoUnknown(form.frameworkContract);
  const mappedComplexityState = mapComplexityState(form.requirements);

  let score = 35;
  score += getSimCountPoints(simCount);
  score += getContractAgePoints(contractAge);
  score += getAverageCostPoints(avgCostPerSim);
  score += getDevicePoints(mappedDeviceState);
  score += getAddOnPoints(mappedAddOnIntensity);
  score += getFrameworkPoints(mappedFrameworkState);
  score += getComplexityPoints(mappedComplexityState);
  score = Math.min(Math.max(score, 0), 100);

  const expectedRate = 0.15 + (score / 100) * 0.15;
  const dataCompleteness = calculateCompleteness(form);
  const width = dataCompleteness >= 0.6 ? 0.05 : 0.07;
  const lowRate = Math.min(Math.max(expectedRate - width, 0.15), 0.3);
  const highRate = Math.min(Math.max(expectedRate + width, 0.15), 0.3);

  const lowMonthlySavings = roundToNearest(monthlyCost * lowRate, 10);
  const expectedMonthlySavings = roundToNearest(monthlyCost * expectedRate, 10);
  const highMonthlySavings = roundToNearest(monthlyCost * highRate, 10);

  return {
    lowMonthlySavings,
    expectedMonthlySavings,
    highMonthlySavings,
    yearlyLowSavings: roundToNearest(lowMonthlySavings * 12, 100),
    yearlyExpectedSavings: roundToNearest(expectedMonthlySavings * 12, 100),
    yearlyHighSavings: roundToNearest(highMonthlySavings * 12, 100),
    lowRate,
    expectedRate,
    highRate,
    dataCompleteness,
  };
}

function calculateCompleteness(form: AnalysisForm) {
  const known = [
    parseFloat(form.contractAge) > 0,
    mapDeviceState(form.deviceCosts) !== "unknown",
    mapAddOnIntensity(form.addOns) !== "unknown",
    mapYesNoUnknown(form.frameworkContract) !== "unknown",
    mapComplexityState(form.requirements) !== "unknown",
  ].filter(Boolean).length;
  return Math.min(Math.max(known / 5, 0), 1);
}

function getSimCountPoints(simCount: number) {
  if (simCount <= 5) return 0;
  if (simCount <= 15) return 6;
  if (simCount <= 50) return 10;
  return 14;
}

function getContractAgePoints(contractAge: number) {
  if (contractAge <= 0) return 0;
  if (contractAge < 12) return -2;
  if (contractAge < 24) return 3;
  if (contractAge <= 36) return 8;
  return 12;
}

function getAverageCostPoints(avgCostPerSim: number) {
  if (avgCostPerSim < 20) return -3;
  if (avgCostPerSim <= 35) return 3;
  if (avgCostPerSim <= 50) return 8;
  return 12;
}

function getDevicePoints(deviceState: string) {
  if (deviceState === "yes") return -6;
  if (deviceState === "no") return 4;
  return 0;
}

function getAddOnPoints(addOnIntensity: string) {
  if (addOnIntensity === "none") return 2;
  if (addOnIntensity === "some") return 6;
  if (addOnIntensity === "many") return 10;
  return 0;
}

function getFrameworkPoints(frameworkState: string) {
  if (frameworkState === "yes") return -6;
  if (frameworkState === "no") return 8;
  return 0;
}

function getComplexityPoints(complexityState: string) {
  if (complexityState === "yes") return 4;
  return 0;
}

function mapDeviceState(deviceCosts: string) {
  if (deviceCosts === "Ja") return "yes";
  if (deviceCosts === "Nein") return "no";
  return "unknown";
}

function mapYesNoUnknown(value: string) {
  if (value === "Ja") return "yes";
  if (value === "Nein") return "no";
  return "unknown";
}

function mapAddOnIntensity(addOns: string) {
  const normalized = addOns.trim().toLowerCase();
  if (!normalized) return "unknown";
  if (["keine", "none", "nein", "ohne", "no"].includes(normalized)) return "none";
  const strongKeywords = ["international", "ausland", "multisim", "datenboost", "data", "security", "versicherung", "streaming", "iot"];
  const matches = strongKeywords.filter(kw => normalized.includes(kw)).length;
  const separatorCount = normalized.split(/[,+/&]/).filter(p => p.trim().length > 0).length;
  if (matches >= 3 || separatorCount >= 3) return "many";
  return "some";
}

function mapComplexityState(requirements: string) {
  if (!requirements.trim().toLowerCase()) return "unknown";
  return "yes";
}

function roundToNearest(value: number, step: number) {
  return Math.round(value / step) * step;
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("de-DE", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value: number) {
  return new Intl.NumberFormat("de-DE", {
    style: "percent",
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(value);
}
