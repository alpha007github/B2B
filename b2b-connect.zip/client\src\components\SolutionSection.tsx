/**
 * Solution Section – Enterprise Beratung Style
 * Warm charcoal background, no italic, KI analysiert + Mensch optimiert
 */
import { motion } from "framer-motion";
import { ArrowRight, Check } from "lucide-react";

const features = [
  {
    title: "KI-gestützte Gesamtanalyse",
    description:
      "Unsere KI analysiert Mobilfunk, Internet und Festnetz gleichzeitig – und findet Einsparpotenziale, die bei isolierter Betrachtung unsichtbar bleiben.",
  },
  {
    title: "Bestes Preis-Leistungs-Verhältnis",
    description:
      "Automatischer Abgleich Ihrer Nutzungsdaten mit allen verfügbaren Tarifen am Markt. Ihr Ansprechpartner bewertet die Ergebnisse individuell.",
  },
  {
    title: "Automatische Vertragsprüfung",
    description:
      "Bestehende Verträge werden kontinuierlich analysiert – inklusive Kündigungsfristen und Einsparpotenzial. Ihr Berater bewertet die Wechselsinnhaftigkeit persönlich.",
  },
  {
    title: "Anbieterübergreifende Optimierung",
    description:
      "100% unabhängig von einzelnen Anbietern. Wir vergleichen alle relevanten Netzbetreiber und finden gemeinsam mit Ihnen die objektiv beste Lösung.",
  },
];

const benefits = [
  "Bis zu 30% Kosteneinsparung",
  "Vollständige Vertragstransparenz",
  "Automatisierte Analyse + persönliche Bewertung",
  "Datenbasierte Entscheidungsvorlagen",
  "Kostenlos und unverbindlich",
  "Ohne Anbieterbindung",
];

export default function SolutionSection() {
  return (
    <section className="py-24 lg:py-32 bg-[#2c2520]">
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <div className="accent-line-light mx-auto mb-6" />
          <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#b5a88e] mb-4">
            Die Lösung
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-6">
            Eine KI-gestützte Lösung für Ihre gesamte Telekommunikation – kombiniert mit persönlicher Beratung
          </h2>
          <p className="text-white/60 text-[16px] leading-relaxed">
            Mobilfunk, Internet und Festnetz werden als zusammenhängendes System analysiert.
            Ihr persönlicher Ansprechpartner bewertet die Ergebnisse und begleitet Sie bis zur Umsetzung.
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start mb-20">
          {/* Left: Feature list */}
          <div className="space-y-8">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="group"
              >
                <div className="flex gap-5">
                  <div className="w-[2px] bg-white/15 group-hover:bg-[#d4c9a8] transition-colors duration-300 shrink-0" />
                  <div>
                    <h3 className="font-display text-xl text-white mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-white/50 leading-relaxed text-[15px]">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Right: Benefits */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-white/5 border border-white/10 p-10">
              <h3 className="font-display text-xl text-white mb-8">
                Was Sie von unserer Analyse erhalten
              </h3>
              <div className="space-y-4">
                {benefits.map((benefit, i) => (
                  <motion.div
                    key={benefit}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.3, delay: 0.4 + i * 0.05 }}
                    className="flex items-center gap-3"
                  >
                    <Check className="w-4 h-4 text-[#d4c9a8] shrink-0" />
                    <span className="text-white/70 text-[15px]">{benefit}</span>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 pt-6 border-t border-white/10">
                <p className="text-white/40 text-[13px]">
                  Unsere KI analysiert – unsere Experten optimieren gemeinsam mit Ihnen.
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a
            href="#kontakt"
            className="group inline-flex items-center justify-center gap-3 px-8 py-4 bg-white text-[#2c2520] text-[13px] font-semibold tracking-[0.08em] uppercase hover:bg-[#f0ece4] transition-all duration-300"
          >
            Jetzt kostenlos analysieren
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#kontakt"
            className="inline-flex items-center justify-center gap-3 px-8 py-4 border border-white/20 text-white text-[13px] font-semibold tracking-[0.08em] uppercase hover:bg-white/5 transition-all duration-300"
          >
            Erstgespräch buchen
          </a>
        </motion.div>
      </div>
    </section>
  );
}
