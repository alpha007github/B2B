/**
 * USP Section – NEW per briefing
 * "Warum KI allein nicht reicht"
 * Enterprise Beratung Style, Beige/Sandton
 */
import { motion } from "framer-motion";
import { Brain, Users, ArrowRight } from "lucide-react";

export default function USPSection() {
  return (
    <section className="py-24 lg:py-32 bg-[#f5f1eb]" id="usp">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="accent-line mb-6" />
            <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
              Unser Ansatz
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#2c2520] leading-tight mb-8">
              Warum KI allein nicht reicht
            </h2>
            <div className="space-y-5 text-[16px] text-[#6b6055] leading-relaxed">
              <p>
                Viele Tools analysieren Daten.
                Aber Telekommunikation braucht Einordnung.
              </p>
              <p>
                Tarife, Laufzeiten, Anbieterstrategien und technische Anforderungen
                müssen richtig bewertet werden.
              </p>
              <p>
                Deshalb kombinieren wir KI-Analyse mit persönlicher Beratung.
              </p>
            </div>
          </motion.div>

          {/* Right: Highlight Cards */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="space-y-6"
          >
            {/* KI Card */}
            <div className="bg-white p-8 border border-[#e8e2d8]">
              <div className="flex items-start gap-5">
                <div className="w-12 h-12 bg-[#f5f1eb] flex items-center justify-center shrink-0">
                  <Brain className="w-6 h-6 text-[#5c5347]" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#2c2520] text-lg mb-2">KI liefert die Analyse</h3>
                  <p className="text-[#6b6055] text-[15px] leading-relaxed">
                    Automatisierte Erkennung von Einsparpotenzial, Vertragsfristen und Marktvergleichen in Echtzeit.
                  </p>
                </div>
              </div>
            </div>

            {/* Mensch Card */}
            <div className="bg-white p-8 border border-[#e8e2d8]">
              <div className="flex items-start gap-5">
                <div className="w-12 h-12 bg-[#f5f1eb] flex items-center justify-center shrink-0">
                  <Users className="w-6 h-6 text-[#5c5347]" />
                </div>
                <div>
                  <h3 className="font-semibold text-[#2c2520] text-lg mb-2">Wir liefern die Betreuung</h3>
                  <p className="text-[#6b6055] text-[15px] leading-relaxed">
                    Ihr persönlicher Ansprechpartner bewertet die Ergebnisse, berät Sie individuell und begleitet die Umsetzung.
                  </p>
                </div>
              </div>
            </div>

            {/* CTA */}
            <a
              href="#kontakt"
              className="group inline-flex items-center gap-2 text-[#5c5347] text-[14px] font-medium hover:text-[#2c2520] transition-colors pt-2"
            >
              Jetzt persönlich beraten lassen
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
