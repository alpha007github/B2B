/**
 * Problem Section – Enterprise Beratung Style
 * White background, warm accents, no italic
 */
import { motion } from "framer-motion";

const problems = [
  {
    number: "01",
    title: "Fragmentierte Verträge",
    description:
      "Mobilfunk bei Anbieter A, Internet bei B, Festnetz bei C – ohne Gesamtüberblick zahlen Sie garantiert zu viel.",
  },
  {
    number: "02",
    title: "Unkontrolliertes Wachstum",
    description:
      "Historisch gewachsene Strukturen ohne zentrale Strategie führen zu massiver Ineffizienz und versteckten Kosten.",
  },
  {
    number: "03",
    title: "Keine Transparenz",
    description:
      "Versteckte Gebühren, ungenutzte Leistungen und veraltete Tarife belasten Ihr Budget – ohne dass Sie es merken.",
  },
  {
    number: "04",
    title: "Verpasste Wechselzeitpunkte",
    description:
      "Verträge verlängern sich automatisch zu schlechteren Konditionen, weil niemand die Fristen aktiv überwacht.",
  },
];

export default function ProblemSection() {
  return (
    <section className="py-24 lg:py-32 bg-white" id="vorteile">
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-20"
        >
          <div className="accent-line mb-6" />
          <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
            Das Problem
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#2c2520] leading-tight mb-6">
            Warum Unternehmen bei Telekommunikation systematisch zu viel zahlen
          </h2>
          <p className="text-[#6b6055] text-[16px] leading-relaxed">
            Die meisten Unternehmen haben keine Transparenz über ihre tatsächlichen
            Kommunikationskosten. Fragmentierte Verträge und fehlende Überwachung kosten bares Geld.
          </p>
        </motion.div>

        {/* Problem Cards – 2 column grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-[#e8e2d8]">
          {problems.map((problem, i) => (
            <motion.div
              key={problem.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white p-10 lg:p-12 group hover:bg-[#faf8f5] transition-colors duration-300"
            >
              <span className="font-display text-5xl text-[#e8e2d8] block mb-4">
                {problem.number}
              </span>
              <h3 className="font-semibold text-xl lg:text-2xl text-[#2c2520] mb-3">
                {problem.title}
              </h3>
              <p className="text-[#6b6055] leading-relaxed text-[15px]">
                {problem.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <a
            href="#ki-rechner"
            className="group inline-flex items-center gap-3 text-[#5c5347] font-medium hover:text-[#2c2520] transition-colors duration-300"
          >
            <span className="text-[13px] tracking-[0.08em] uppercase">Jetzt Einsparpotenzial berechnen</span>
            <span className="group-hover:translate-x-1 transition-transform">→</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
