/**
 * Navbar – Enterprise Beratung Style
 * Clean, warm, Beige/Sandton palette
 * Uses real Deutsche B2B Connect logo
 */
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";

const LOGO_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663402102331/gRTBQK4PqUxRYVZGKudTAJ/logo-full_09f11d5a.png";
const LOGO_WHITE_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310519663402102331/gRTBQK4PqUxRYVZGKudTAJ/logo-white_2df4fc26.png";

const navLinks = [
  { label: "Vorteile", href: "#vorteile" },
  { label: "So funktioniert's", href: "#prozess" },
  { label: "Leistungen", href: "#leistungen" },
  { label: "Über uns", href: "#team" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-[#faf8f5]/95 backdrop-blur-md shadow-[0_1px_0_rgba(0,0,0,0.06)] py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="shrink-0">
          <img
            src={scrolled ? LOGO_URL : LOGO_WHITE_URL}
            alt="Deutsche B2B Connect"
            className="h-10 md:h-12 w-auto transition-all duration-300"
          />
        </a>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-10">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`text-[13px] font-medium tracking-[0.08em] uppercase transition-colors duration-200 ${
                scrolled
                  ? "text-charcoal/60 hover:text-charcoal"
                  : "text-white/70 hover:text-white"
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-5">
          <a
            href="#kontakt"
            className={`text-[13px] font-medium tracking-[0.08em] uppercase transition-colors duration-200 ${
              scrolled
                ? "text-charcoal/60 hover:text-charcoal"
                : "text-white/70 hover:text-white"
            }`}
          >
            Erstgespräch
          </a>
          <a
            href="#ki-rechner"
            className={`inline-flex items-center px-6 py-2.5 text-[12px] font-semibold tracking-[0.1em] uppercase transition-all duration-300 ${
              scrolled
                ? "bg-charcoal text-white hover:bg-charcoal-light"
                : "bg-white/10 backdrop-blur-sm border border-white/30 text-white hover:bg-white/20"
            }`}
          >
            KI-Analyse starten
          </a>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className={`lg:hidden p-2 transition-colors ${scrolled ? "text-charcoal" : "text-white"}`}
          aria-label="Menü"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-[#faf8f5] overflow-hidden border-t border-sand-dark/30"
          >
            <div className="container py-6 flex flex-col gap-1">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={() => setMobileOpen(false)}
                  className="text-sm font-medium text-charcoal tracking-wide uppercase py-3 border-b border-sand-dark/30 last:border-0"
                >
                  {link.label}
                </a>
              ))}
              <div className="flex flex-col gap-3 pt-5 mt-2">
                <a
                  href="#kontakt"
                  onClick={() => setMobileOpen(false)}
                  className="text-center py-3 border border-charcoal text-charcoal text-sm font-semibold tracking-wide uppercase"
                >
                  Erstgespräch vereinbaren
                </a>
                <a
                  href="#ki-rechner"
                  onClick={() => setMobileOpen(false)}
                  className="text-center py-3 bg-charcoal text-white text-sm font-semibold tracking-wide uppercase"
                >
                  KI-Analyse starten
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
