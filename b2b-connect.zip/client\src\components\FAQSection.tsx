/**
 * FAQ Section – Enterprise Beratung Style
 * Warm sand background, no italic, updated colors
 */
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    category: "KI-Analyse",
    question: "Wie funktioniert die KI-gestützte Vertragsanalyse?",
    answer:
      "Unsere KI erfasst Ihre gesamte Telekommunikationsstruktur – Mobilfunk, Internet und Festnetz – und gleicht sie in Echtzeit mit allen verfügbaren Tarifen am Markt ab. Dabei werden Nutzungsmuster, Vertragslaufzeiten und versteckte Kosten identifiziert. Ihr persönlicher Ansprechpartner bewertet die Ergebnisse und leitet die passenden Maßnahmen ein.",
  },
  {
    category: "KI-Analyse",
    question: "Ist die KI-Analyse wirklich kostenlos?",
    answer:
      "Ja, die Erstanalyse ist vollständig kostenlos und unverbindlich. Sie erhalten einen detaillierten Bericht über Ihr Einsparpotenzial, ohne jegliche Verpflichtung. Erst wenn Sie sich für eine Optimierung entscheiden, entstehen Kosten.",
  },
  {
    category: "Einsparungen",
    question: "Wie hoch sind die typischen Einsparungen?",
    answer:
      "Unsere Kunden erzielen durchschnittlich 20 bis 30 Prozent Einsparung auf ihre gesamten Telekommunikationskosten. Bei Unternehmen mit historisch gewachsenen Vertragsstrukturen und vielen SIM-Karten liegt das Potenzial häufig noch höher. Die genaue Höhe hängt von Ihrer individuellen Vertragslandschaft ab.",
  },
  {
    category: "Einsparungen",
    question: "Warum zahlen Unternehmen oft zu viel für Telekommunikation?",
    answer:
      "Die häufigsten Ursachen sind fragmentierte Verträge über mehrere Anbieter, automatische Vertragsverlängerungen zu ungünstigen Konditionen, ungenutzte Leistungspakete und fehlende Transparenz über die tatsächliche Nutzung. Unsere KI deckt genau diese Ineffizienzen systematisch auf.",
  },
  {
    category: "Vertragsprüfung",
    question: "Wie prüft die KI bestehende Verträge auf Wechselsinnhaftigkeit?",
    answer:
      "Die KI überwacht kontinuierlich Ihre Vertragslaufzeiten, Kündigungsfristen und aktuelle Marktangebote. Sobald ein Wechsel wirtschaftlich sinnvoll ist, erhalten Sie eine datenbasierte Empfehlung. Ihr persönlicher Berater bewertet diese und bespricht die Optionen mit Ihnen.",
  },
  {
    category: "Vertragsprüfung",
    question: "Was passiert mit meinen bestehenden Verträgen?",
    answer:
      "Bestehende Verträge werden nicht einfach gekündigt. Wir analysieren zunächst, ob ein Wechsel tatsächlich vorteilhaft ist. Nur wenn das Einsparpotenzial die Wechselkosten deutlich übersteigt, empfehlen wir eine Migration. Den gesamten Prozess begleiten wir persönlich.",
  },
  {
    category: "Prozess",
    question: "Wie lange dauert der Optimierungsprozess?",
    answer:
      "Die KI-Analyse liefert erste Ergebnisse innerhalb weniger Sekunden. Die vollständige Auswertung mit konkreten Handlungsempfehlungen erhalten Sie in der Regel innerhalb von 24 Stunden. Die Umsetzung einer Optimierung dauert je nach Komplexität zwischen zwei und acht Wochen.",
  },
  {
    category: "Prozess",
    question: "Für welche Unternehmensgrößen ist das Angebot geeignet?",
    answer:
      "Unser Angebot richtet sich an Unternehmen mit circa 20 bis über 2.000 SIM-Karten bzw. Anschlüssen. Besonders profitieren Unternehmen mit mehreren Standorten, mobilen Teams oder historisch gewachsenen Vertragsstrukturen.",
  },
  {
    category: "Sicherheit",
    question: "Wie sicher sind meine Daten bei der Analyse?",
    answer:
      "Datenschutz hat für uns höchste Priorität. Alle Daten werden DSGVO-konform verarbeitet und auf deutschen Servern gespeichert. Ihre Vertragsdaten werden ausschließlich für die Analyse verwendet und nicht an Dritte weitergegeben.",
  },
  {
    category: "Sicherheit",
    question: "Sind Sie an bestimmte Anbieter gebunden?",
    answer:
      "Nein, wir arbeiten zu 100 Prozent anbieterunabhängig. Wir haben keine exklusiven Partnerschaften oder Provisionsvereinbarungen mit einzelnen Netzbetreibern. Unsere Empfehlungen basieren ausschließlich auf dem objektiv besten Preis-Leistungs-Verhältnis für Ihr Unternehmen.",
  },
];

function FAQItem({
  faq,
  isOpen,
  onToggle,
  index,
}: {
  faq: (typeof faqs)[0];
  isOpen: boolean;
  onToggle: () => void;
  index: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="border-b border-[#e8e2d8] last:border-b-0"
    >
      <button
        onClick={onToggle}
        className="w-full flex items-start justify-between py-6 text-left group"
        aria-expanded={isOpen}
      >
        <div className="faq-question-row pr-4">
          <span className="faq-category-label text-[#8a7e6b] text-[11px] font-medium tracking-[0.15em] uppercase mt-1 hidden sm:block">
            {faq.category}
          </span>
          <span
            className={`min-w-0 font-semibold text-lg transition-colors duration-300 ${
              isOpen ? "text-[#2c2520]" : "text-[#5c5347] group-hover:text-[#2c2520]"
            }`}
          >
            {faq.question}
          </span>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="shrink-0 mt-1"
        >
          <ChevronDown
            className={`w-5 h-5 transition-colors duration-300 ${
              isOpen ? "text-[#5c5347]" : "text-[#b5a88e]"
            }`}
          />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.4, 0, 0.2, 1] }}
            className="overflow-hidden"
          >
            <div className="faq-answer-copy pb-6 pr-10">
              <p className="text-[#6b6055] leading-relaxed text-[15px]">
                {faq.answer}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 lg:py-32 bg-[#f5f1eb]" id="faq">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Left: Intro */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-4"
          >
            <div className="lg:sticky lg:top-32">
              <div className="accent-line mb-6" />
              <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
                Häufige Fragen
              </p>
              <h2 className="font-display text-3xl sm:text-4xl text-[#2c2520] leading-tight mb-6">
                Alles, was Sie wissen sollten
              </h2>
              <p className="text-[#6b6055] leading-relaxed text-[15px] mb-8">
                Transparenz ist einer unserer Grundwerte. Hier finden Sie Antworten auf die
                häufigsten Fragen zu unserer KI-gestützten Analyse und den
                erzielbaren Einsparungen.
              </p>

              {/* CTA within FAQ */}
              <div className="border-t border-[#d8d0c4] pt-8">
                <p className="text-[#2c2520] font-medium text-sm mb-4">
                  Ihre Frage ist nicht dabei?
                </p>
                <a
                  href="#kontakt"
                  className="inline-flex items-center gap-2 text-[#5c5347] text-[13px] font-medium tracking-[0.08em] uppercase hover:text-[#2c2520] transition-colors duration-300"
                >
                  <span>Persönlich beraten lassen</span>
                  <span>→</span>
                </a>
              </div>
            </div>
          </motion.div>

          {/* Right: FAQ Items */}
          <div className="lg:col-span-8">
            <div className="bg-white border border-[#e8e2d8] p-6 sm:p-8 lg:p-10">
              {faqs.map((faq, index) => (
                <FAQItem
                  key={index}
                  faq={faq}
                  index={index}
                  isOpen={openIndex === index}
                  onToggle={() =>
                    setOpenIndex(openIndex === index ? null : index)
                  }
                />
              ))}
            </div>

            {/* Bottom note */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mt-8 flex items-center gap-4 text-[#8a7e6b] text-[13px]"
            >
              <div className="accent-line" />
              <p>
                Noch Fragen? Rufen Sie uns an oder starten Sie direkt mit der{" "}
                <a
                  href="#kontakt"
                  className="text-[#5c5347] hover:text-[#2c2520] transition-colors"
                >
                  kostenlosen KI-Analyse
                </a>
                .
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
