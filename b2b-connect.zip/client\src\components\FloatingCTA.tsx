/**
 * Floating CTA – Enterprise Beratung Style
 * Subtle bottom bar, warm palette
 */
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight } from "lucide-react";

export default function FloatingCTA() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 800);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="fixed bottom-0 left-0 right-0 z-40 bg-[#faf8f5]/95 backdrop-blur-md border-t border-[#e8e2d8] py-3 shadow-lg"
        >
          <div className="container flex items-center justify-between gap-4">
            <p className="hidden sm:block text-[14px] text-[#5c5347]">
              Bis zu <span className="text-[#2c2520] font-semibold">30% Einsparpotenzial</span> bei Ihren Telekommunikationskosten
            </p>
            <div className="flex items-center gap-3 ml-auto">
              <a
                href="#kontakt"
                className="text-[13px] text-[#5c5347] font-medium hover:text-[#2c2520] transition-colors hidden sm:block"
              >
                Erstgespräch
              </a>
              <a
                href="#ki-rechner"
                className="group inline-flex items-center gap-2 px-5 py-2.5 bg-[#2c2520] text-white text-[12px] font-semibold tracking-[0.08em] uppercase hover:bg-[#3d3530] transition-all duration-300"
              >
                KI-Analyse starten
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </a>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
