/**
 * Footer – Enterprise Beratung Style
 * Warm charcoal background
 */

const LOGO_WHITE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663402102331/gRTBQK4PqUxRYVZGKudTAJ/logo-white_2df4fc26.png";

export default function Footer() {
  return (
    <footer className="bg-[#1e1a16] py-16">
      <div className="container">
        {/* Top: Logo + Links */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12 pb-12 border-b border-white/10">
          {/* Logo */}
          <div className="md:col-span-1">
            <img
              src={LOGO_WHITE}
              alt="Deutsche B2B Connect"
              className="h-10 w-auto mb-4"
            />
            <p className="text-white/40 text-[14px] leading-relaxed">
              KI-gestützte Analyse.
              <br />
              Persönliche Betreuung.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-[11px] font-medium text-white/50 tracking-[0.15em] uppercase mb-4">
              Navigation
            </h4>
            <ul className="space-y-3">
              {[
                { label: "Vorteile", href: "#vorteile" },
                { label: "So funktioniert's", href: "#prozess" },
                { label: "Leistungen", href: "#leistungen" },
                { label: "Über uns", href: "#team" },
                { label: "FAQ", href: "#faq" },
              ].map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-white/40 text-[14px] hover:text-white/70 transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Leistungen */}
          <div>
            <h4 className="text-[11px] font-medium text-white/50 tracking-[0.15em] uppercase mb-4">
              Leistungen
            </h4>
            <ul className="space-y-3">
              {["Mobilfunk", "Internet", "Cloud-Telefonie", "IT-Sicherheit", "Beratung"].map((item) => (
                <li key={item}>
                  <a
                    href="#leistungen"
                    className="text-white/40 text-[14px] hover:text-white/70 transition-colors"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Kontakt */}
          <div>
            <h4 className="text-[11px] font-medium text-white/50 tracking-[0.15em] uppercase mb-4">
              Kontakt
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="mailto:kontakt@deutsche-b2b-connect.com"
                  className="text-white/40 text-[14px] hover:text-white/70 transition-colors"
                >
                  kontakt@deutsche-b2b-connect.com
                </a>
              </li>
              <li className="text-white/40 text-[14px]">
                Mo – Fr 08:00 – 18:00 Uhr
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-[12px]">
            &copy; {new Date().getFullYear()} Deutsche B2B Connect GmbH. Alle Rechte vorbehalten.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-white/25 text-[12px] hover:text-white/50 transition-colors">
              Impressum
            </a>
            <a href="#" className="text-white/25 text-[12px] hover:text-white/50 transition-colors">
              Datenschutz
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
