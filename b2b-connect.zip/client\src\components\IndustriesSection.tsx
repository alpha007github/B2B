/**
 * Independence / Industries Section – Enterprise Beratung Style
 * Warm charcoal overlay, no italic
 */
import { motion } from "framer-motion";
import { Check } from "lucide-react";

const INDEPENDENCE_BG = "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=1920&q=80";

const industries = [
  "Start-ups & Gründer",
  "Mittelständische Unternehmen",
  "Handwerk & Gewerbe",
  "Gesundheitswesen & Praxen",
  "Rechts- & Steuerberatung",
  "Gastronomie & Hotellerie",
  "Logistik & Transport",
  "Einzelhandel & Filialisten",
];

export default function IndustriesSection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden" id="branchen">
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src={INDEPENDENCE_BG}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-[#2c2520]/90" />
      </div>

      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: Statement */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="accent-line-light mb-6" />
            <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#b5a88e] mb-4">
              Unabhängigkeit als Prinzip
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-6">
              Kein Business-Partner.
              <br />
              <span className="text-[#d4c9a8]">Ihr Partner.</span>
            </h2>
            <p className="text-white/60 text-[16px] leading-relaxed mb-8">
              Wir arbeiten mit allen relevanten Netzbetreibern und Anbietern zusammen –
              entscheiden uns aber immer für das, was für Sie am besten ist.
              Keine versteckten Provisionsinteressen, keine Anbieterbindung.
            </p>

            {/* Key points */}
            <div className="space-y-4">
              {[
                "Vertrieb mit Verantwortung – Beratung vor Verkauf",
                "Persönlicher Ansprechpartner – keine Systeme",
                "100% Fokus auf B2B – von Selbstständigen bis zum Mittelstand",
              ].map((point) => (
                <div key={point} className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#d4c9a8] mt-0.5 shrink-0" />
                  <span className="text-white/80 text-[15px]">{point}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right: Industries */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="font-display text-2xl text-white mb-8">
              Branchen, die wir betreuen
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {industries.map((industry, i) => (
                <motion.div
                  key={industry}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: 0.3 + i * 0.05 }}
                  className="flex items-center gap-3 py-3 border-b border-white/10"
                >
                  <div className="w-1.5 h-1.5 bg-[#d4c9a8] shrink-0" />
                  <span className="text-white/80 text-[15px]">{industry}</span>
                </motion.div>
              ))}
            </div>

            <p className="text-white/40 text-[13px] mt-6">
              Ihre Branche ist nicht dabei? Wir optimieren jedes Unternehmen mit komplexer Telekommunikationsstruktur.
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
