/**
 * CTA / Contact Section – Enterprise Beratung Style
 * Warm charcoal background, no italic
 */
import { motion } from "framer-motion";
import { ArrowRight, Mail, Phone, Clock } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-24 lg:py-32 bg-[#2c2520]" id="kontakt">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Left: CTA Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="accent-line-light mb-6" />
            <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#b5a88e] mb-4">
              Kontakt
            </p>
            <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-white leading-tight mb-6">
              Bereit für optimale Kosten?
            </h2>
            <p className="text-white/60 text-[16px] leading-relaxed mb-10">
              Starten Sie mit einer kostenlosen KI-Analyse oder vereinbaren Sie ein
              unverbindliches Erstgespräch. Wir zeigen Ihnen, wie viel Einsparpotenzial
              in Ihrer Telekommunikation steckt.
            </p>

            {/* Two CTA options */}
            <div className="space-y-6 mb-12">
              <a
                href="#ki-rechner"
                className="group flex items-center gap-5 p-6 border border-white/10 hover:border-[#d4c9a8]/50 hover:bg-white/5 transition-all duration-300"
              >
                <div className="w-14 h-14 bg-white/10 flex items-center justify-center shrink-0">
                  <ArrowRight className="w-6 h-6 text-[#d4c9a8]" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white mb-1">KI-Analyse starten</h3>
                  <p className="text-white/50 text-sm">Kostenlos und unverbindlich – Ergebnisse in Sekunden</p>
                </div>
              </a>

              <a
                href="#kontakt"
                className="group flex items-center gap-5 p-6 border border-white/10 hover:border-[#d4c9a8]/50 hover:bg-white/5 transition-all duration-300"
              >
                <div className="w-14 h-14 border border-white/20 flex items-center justify-center shrink-0">
                  <Phone className="w-6 h-6 text-[#d4c9a8]" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-white mb-1">Erstgespräch vereinbaren</h3>
                  <p className="text-white/50 text-sm">Persönliche Beratung durch unsere Experten</p>
                </div>
              </a>
            </div>

            {/* Contact Info */}
            <div className="space-y-4 pt-8 border-t border-white/10">
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#b5a88e]" />
                <a href="mailto:kontakt@deutsche-b2b-connect.com" className="text-white/70 text-sm hover:text-white transition-colors">
                  kontakt@deutsche-b2b-connect.com
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-[#b5a88e]" />
                <span className="text-white/70 text-sm">Mo – Fr 08:00 – 18:00 Uhr</span>
              </div>
            </div>
          </motion.div>

          {/* Right: Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-[#faf8f5] p-8 lg:p-10">
              <h3 className="font-display text-2xl text-[#2c2520] mb-2">
                Kontaktieren Sie uns
              </h3>
              <p className="text-[#6b6055] text-[15px] mb-8">
                Ihr Anliegen ist bei uns in guten Händen. Wir beraten Sie persönlich und finden gemeinsam die passende Lösung.
              </p>

              <form className="space-y-5" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                      Name *
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] placeholder:text-[#b5a88e] focus:border-[#8a7e6b] focus:outline-none transition-colors bg-white"
                      placeholder="Ihr Name"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                      Unternehmen
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] placeholder:text-[#b5a88e] focus:border-[#8a7e6b] focus:outline-none transition-colors bg-white"
                      placeholder="Ihr Unternehmen"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                      E-Mail *
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] placeholder:text-[#b5a88e] focus:border-[#8a7e6b] focus:outline-none transition-colors bg-white"
                      placeholder="ihre@email.de"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                      Telefon *
                    </label>
                    <input
                      type="tel"
                      className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] placeholder:text-[#b5a88e] focus:border-[#8a7e6b] focus:outline-none transition-colors bg-white"
                      placeholder="+49 ..."
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                    Anzahl SIM-Karten / Anschlüsse
                  </label>
                  <select className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] focus:border-[#8a7e6b] focus:outline-none transition-colors bg-white">
                    <option value="placeholder">Bitte wählen</option>
                    <option value="1-20">1 – 20</option>
                    <option value="21-50">21 – 50</option>
                    <option value="51-200">51 – 200</option>
                    <option value="201-500">201 – 500</option>
                    <option value="500+">500+</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[#8a7e6b] tracking-[0.1em] uppercase mb-2">
                    Nachricht
                  </label>
                  <textarea
                    rows={4}
                    className="w-full px-4 py-3 border border-[#e8e2d8] text-sm text-[#2c2520] placeholder:text-[#b5a88e] focus:border-[#8a7e6b] focus:outline-none transition-colors resize-none bg-white"
                    placeholder="Beschreiben Sie kurz Ihr Anliegen..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-[#2c2520] text-white text-[13px] font-semibold tracking-[0.08em] uppercase hover:bg-[#3d3530] transition-all duration-300"
                >
                  Anfrage absenden
                </button>

                <p className="text-[12px] text-[#8a7e6b] leading-relaxed">
                  Mit dem Absenden stimmen Sie der Verarbeitung Ihrer Daten gemäß unserer Datenschutzerklärung zu.
                </p>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
