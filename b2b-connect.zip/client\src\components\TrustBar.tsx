/**
 * TrustBar – Enterprise Beratung Style
 * Warm sand background, monochrome logos, trust indicators
 */
import { motion } from "framer-motion";

export default function TrustBar() {
  return (
    <section className="bg-[#f5f1eb] py-10 border-b border-[#e8e2d8]">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <p className="text-[12px] tracking-[0.15em] uppercase text-[#8a7e6b] mb-6">
            Vertrauen von Unternehmen, die ihre Telekommunikation professionell steuern
          </p>

          {/* Placeholder for 4-6 reference logos (monochrome/gray) */}
          <div className="flex items-center justify-center gap-10 md:gap-16 mb-6 opacity-30">
            {["Referenz 1", "Referenz 2", "Referenz 3", "Referenz 4", "Referenz 5"].map((name, i) => (
              <div
                key={i}
                className="w-24 h-8 bg-[#8a7e6b]/10 rounded flex items-center justify-center"
              >
                <span className="text-[10px] text-[#8a7e6b] tracking-wide">{name}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-4 text-[13px] text-[#5c5347]">
            <span className="font-medium">100+ Geschäftskunden</span>
            <span className="text-[#8a7e6b]/40 hidden sm:inline">·</span>
            <span className="font-medium">100% anbieterunabhängig</span>
            <span className="text-[#8a7e6b]/40 hidden sm:inline">·</span>
            <span className="font-medium">Persönliche Betreuung statt Hotline</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
