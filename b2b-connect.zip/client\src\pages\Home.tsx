/**
 * Home Page – Enterprise Beratung Style
 * Warm Beige/Sandton palette, no italic
 * Section order per client briefing:
 * Hero → TrustBar → Team (Gründer) → USP → Problem → Solution → Process → Services → Industries → FAQ → CTA → Footer
 */
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import TrustBar from "@/components/TrustBar";
import TeamSection from "@/components/TeamSection";
import USPSection from "@/components/USPSection";
import ProblemSection from "@/components/ProblemSection";
import SolutionSection from "@/components/SolutionSection";
import ProcessSection from "@/components/ProcessSection";
import ServicesSection from "@/components/ServicesSection";
import IndustriesSection from "@/components/IndustriesSection";
import AIAnalysisSection from "@/components/AIAnalysisSection";
import FAQSection from "@/components/FAQSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";

export default function Home() {
  return (
    <div className="min-h-screen bg-[#faf8f5] text-foreground">
      <Navbar />
      <HeroSection />
      <TrustBar />
      <TeamSection />
      <USPSection />
      <ProblemSection />
      <SolutionSection />
      <ProcessSection />
      <ServicesSection />
      <IndustriesSection />
      <AIAnalysisSection />
      <FAQSection />
      <CTASection />
      <Footer />
      <FloatingCTA />
    </div>
  );
}
