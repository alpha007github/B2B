/**
 * Process Section – Enterprise Beratung Style
 * Warm sand background, no italic, updated 4-step process
 */
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";

const steps = [
  {
    number: "01",
    title: "Daten erfassen",
    description:
      "Wir erfassen Ihre gesamte Telekommunikationsstruktur – Mobilfunkverträge, Internetanbindungen, Festnetzanschlüsse und Cloud-Telefonie.",
  },
  {
    number: "02",
    title: "KI-Analyse",
    description:
      "Unsere KI erkennt Einsparpotenziale und Fristen. Alle Verträge werden gleichzeitig analysiert und mit dem gesamten Markt verglichen.",
  },
  {
    number: "03",
    title: "Persönliche Bewertung",
    description:
      "Ihr Ansprechpartner bewertet alle Optionen individuell. Gemeinsam entscheiden wir, welche Maßnahmen für Ihr Unternehmen sinnvoll sind.",
  },
  {
    number: "04",
    title: "Umsetzung & Betreuung",
    description:
      "Wir begleiten Sie langfristig – von der Migration bis zur laufenden Überwachung Ihrer Verträge und Kosten.",
  },
];

export default function ProcessSection() {
  return (
    <section className="py-24 lg:py-32 bg-[#f5f1eb]" id="prozess">
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-20"
        >
          <div className="accent-line mx-auto mb-6" />
          <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
            So funktioniert's
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#2c2520] leading-tight mb-6">
            In vier Schritten zur optimalen Kostenstruktur
          </h2>
          <p className="text-[#6b6055] text-[16px] leading-relaxed">
            Von der Analyse bis zur laufenden Betreuung – ein strukturierter Prozess für nachhaltige Ergebnisse.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-[#e8e2d8] mb-16">
          {steps.map((step, i) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white p-8 lg:p-10 relative group"
            >
              {/* Accent top border on hover */}
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-[#8a7e6b] scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              
              <span className="font-display text-6xl text-[#e8e2d8] block mb-4">
                {step.number}
              </span>
              <h3 className="font-semibold text-xl text-[#2c2520] mb-3">
                {step.title}
              </h3>
              <p className="text-[#6b6055] text-[15px] leading-relaxed">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center"
        >
          <a
            href="#kontakt"
            className="group inline-flex items-center gap-3 px-8 py-4 bg-[#2c2520] text-white text-[13px] font-semibold tracking-[0.08em] uppercase hover:bg-[#3d3530] transition-all duration-300"
          >
            Jetzt Prozess starten – kostenlos
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
