/**
 * HeroSection – Enterprise Beratung Style
 * Warm, professional, Beige/Sandton palette
 * No italic, no "Ein KI-Tool" – focus on "Beratung + KI"
 */
import { motion } from "framer-motion";
import { ArrowRight, ChevronDown } from "lucide-react";

const HERO_BG = "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1920&q=80";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background Image with warm overlay */}
      <div className="absolute inset-0">
        <img
          src={HERO_BG}
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#3a3228]/92 via-[#3a3228]/85 to-[#3a3228]/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 container pt-32 pb-24">
        <div className="max-w-3xl">
          {/* Overline */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex items-center gap-3 mb-10"
          >
            <div className="w-10 h-[1px] bg-white/40" />
            <span className="text-[12px] font-medium tracking-[0.2em] uppercase text-white/60">
              KI-gestützte Telekommunikationsoptimierung
            </span>
          </motion.div>

          {/* Headline – no italic */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.1] text-white mb-8"
          >
            KI-gestützte Analyse.
            <br />
            <span className="text-[#d4c9a8]">Persönliche</span>
            <br />
            Betreuung.
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="text-lg md:text-xl text-white/70 leading-relaxed max-w-2xl mb-12 font-light"
          >
            Unsere KI analysiert Mobilfunk, Internet und Festnetz.
            Ihr persönlicher Ansprechpartner macht daraus die beste
            Entscheidung für Ihr Unternehmen.
          </motion.p>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-4 mb-20"
          >
            <a
              href="#ki-rechner"
              className="group inline-flex items-center justify-center gap-3 px-8 py-4 bg-white text-[#3a3228] text-[13px] font-semibold tracking-[0.08em] uppercase transition-all duration-300 hover:bg-[#f0ece4]"
            >
              Kostenlose KI-Analyse starten
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#kontakt"
              className="inline-flex items-center justify-center px-8 py-4 border border-white/30 text-white text-[13px] font-semibold tracking-[0.08em] uppercase transition-all duration-300 hover:bg-white/10"
            >
              Erstgespräch vereinbaren
            </a>
          </motion.div>

          {/* KPI Bar */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="flex flex-wrap gap-x-12 gap-y-6"
          >
            <div>
              <div className="text-2xl md:text-3xl font-display text-white">Bis zu 30%</div>
              <div className="text-[13px] text-white/50 mt-1 tracking-wide">Einsparpotenzial</div>
            </div>
            <div className="w-[1px] bg-white/15 hidden sm:block" />
            <div>
              <div className="text-2xl md:text-3xl font-display text-white">100%</div>
              <div className="text-[13px] text-white/50 mt-1 tracking-wide">Anbieterunabhängig</div>
            </div>
            <div className="w-[1px] bg-white/15 hidden sm:block" />
            <div>
              <div className="text-2xl md:text-3xl font-display text-white">KI + Mensch</div>
              <div className="text-[13px] text-white/50 mt-1 tracking-wide">Analyse & persönliche Betreuung</div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.a
        href="#team"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40 hover:text-white/60 transition-colors"
      >
        <span className="text-[11px] tracking-[0.15em] uppercase">Mehr erfahren</span>
        <ChevronDown className="w-5 h-5 animate-bounce" />
      </motion.a>
    </section>
  );
}
