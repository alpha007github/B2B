/**
 * Services Section – Enterprise Beratung Style
 * White background, warm accents, no italic
 */
import { motion } from "framer-motion";
import { Smartphone, Globe, Phone, Shield, Users } from "lucide-react";

const services = [
  {
    icon: Smartphone,
    title: "Mobilfunk",
    description:
      "Unabhängige Mobilfunklösungen mit Zugang zu allen Netzen, persönlicher Betreuung und attraktiven Business-Konditionen – maßgeschneidert für Ihr Unternehmen.",
  },
  {
    icon: Globe,
    title: "Internet",
    description:
      "Passgenaue Internetlösungen von DSL bis zur metrischen Standleitung – abgestimmt auf Ihre Anforderungen, Standorte und Budgets.",
  },
  {
    icon: Phone,
    title: "Cloud-Telefonie",
    description:
      "Flexible Cloud-Telefonie-Lösungen, die zu Ihren Anforderungen passen – effizient, skalierbar und vollständig integrierbar.",
  },
  {
    icon: Shield,
    title: "IT-Sicherheit",
    description:
      "DSGVO-konforme Lösungen zum Schutz Ihrer mobilen Geräte, Daten und Kommunikationskanäle – zentral steuerbar und einfach integrierbar.",
  },
  {
    icon: Users,
    title: "Unabhängige Beratung",
    description:
      "Anbieterneutrale Beratung mit objektiver Analyse, maßgeschneiderter Lösung und transparenter Empfehlung – ganz im Interesse Ihres Unternehmens.",
  },
];

export default function ServicesSection() {
  return (
    <section className="py-24 lg:py-32 bg-white" id="leistungen">
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mb-20"
        >
          <div className="accent-line mb-6" />
          <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
            Unsere Leistungen
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#2c2520] leading-tight mb-6">
            Das können wir für Sie tun
          </h2>
          <p className="text-[#6b6055] text-[16px] leading-relaxed">
            Wir unterstützen Sie mit passgenauen Lösungen und unabhängiger Beratung,
            stets ausgerichtet auf die Anforderungen Ihres Unternehmens.
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-[#e8e2d8]">
          {services.map((service, i) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="bg-white p-10 group hover:bg-[#faf8f5] transition-colors duration-300"
            >
              <service.icon className="w-7 h-7 text-[#8a7e6b] mb-6 group-hover:text-[#2c2520] transition-colors duration-300" />
              <h3 className="font-semibold text-xl text-[#2c2520] mb-3">
                {service.title}
              </h3>
              <p className="text-[#6b6055] text-[15px] leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}

          {/* CTA Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-[#2c2520] p-10 flex flex-col justify-center"
          >
            <h3 className="font-display text-xl text-white mb-3">
              Alle Leistungen im Detail
            </h3>
            <p className="text-white/60 text-[15px] leading-relaxed mb-6">
              Erfahren Sie mehr über unsere umfassenden Beratungsleistungen und wie wir Ihr Unternehmen unterstützen können.
            </p>
            <a
              href="#kontakt"
              className="inline-flex items-center gap-2 text-[#d4c9a8] text-[13px] font-medium tracking-[0.08em] uppercase hover:text-white transition-colors"
            >
              Kontakt aufnehmen
              <span>→</span>
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
