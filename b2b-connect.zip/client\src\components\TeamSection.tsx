/**
 * TeamSection (Gründer) – Enterprise Beratung Style
 * Moved to directly under Hero per briefing
 * Warm Beige/Sandton palette, no italic
 */
import { motion } from "framer-motion";

const PETER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663402102331/gRTBQK4PqUxRYVZGKudTAJ/peter-walz_9728f0e6.jpeg";
const KILIAN_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663402102331/gRTBQK4PqUxRYVZGKudTAJ/kilian-menger_d9c88ff4.jpeg";

const founders = [
  {
    name: "Dr. Peter Walz",
    role: "Gesellschafter · Ehemaliger Geschäftsführer Vodafone Deutschland",
    description: "Erfahrung auf höchstem Niveau – strategische Telekommunikationslösungen für große Unternehmen und komplexe Infrastrukturen.",
    image: PETER_IMG,
  },
  {
    name: "Kilian Menger de Oliveira",
    role: "Geschäftsführer · 20+ Jahre B2B-Telekommunikation",
    description: "Spezialist für anbieterübergreifende Optimierung, Vertragsstrukturen und wirtschaftliche Effizienz.",
    image: KILIAN_IMG,
  },
];

export default function TeamSection() {
  return (
    <section className="py-24 lg:py-32 bg-white" id="team">
      <div className="container">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <div className="accent-line mx-auto mb-6" />
          <p className="text-[12px] font-medium tracking-[0.2em] uppercase text-[#8a7e6b] mb-4">
            Technologie trifft Erfahrung
          </p>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl text-[#2c2520] leading-tight mb-6">
            Technologie trifft Erfahrung
          </h2>
          <p className="text-[#6b6055] mt-4 max-w-2xl mx-auto text-[16px] leading-relaxed">
            Unsere KI erkennt Einsparpotenziale.
            Unsere Erfahrung sorgt dafür, dass daraus die richtige Entscheidung entsteht.
          </p>
        </motion.div>

        {/* Founders Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-16">
          {founders.map((founder, i) => (
            <motion.div
              key={founder.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.2 }}
            >
              <div className="relative overflow-hidden mb-8">
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={founder.image}
                    alt={founder.name}
                    className="w-full h-full object-cover object-top grayscale"
                  />
                </div>
              </div>

              {/* Name & Role */}
              <div className="border-t border-[#e8e2d8] pt-6">
                <p className="font-semibold text-[#2c2520] text-lg">{founder.name}</p>
                <p className="text-[#8a7e6b] text-sm font-medium mt-1">{founder.role}</p>
                <p className="text-[#6b6055] text-[15px] mt-3 leading-relaxed">{founder.description}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Statement */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="border-t border-[#e8e2d8] pt-12 text-center"
        >
          <p className="text-2xl sm:text-3xl font-semibold text-[#2c2520] leading-snug max-w-2xl mx-auto">
            Unsere KI zeigt, was möglich ist.
            <br />
            Wir entscheiden gemeinsam mit Ihnen, was sinnvoll ist.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
