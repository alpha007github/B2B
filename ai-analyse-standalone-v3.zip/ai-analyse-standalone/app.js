/* ============================================================
   AI-Analyse Standalone – Vollständige Analyse-Logik
   Portiert aus: analysis-imported-section.tsx
   ============================================================ */

'use strict';

// ---- Analyse-Phasen ----
const ANALYSIS_PHASES = [
  {
    code: 'Phase A',
    title: 'Infrastruktur-Abgleich',
    description: 'Abgleich Ihrer aktuellen Tarife und Preise mit dem unabhängigen Markt.',
    steps: [10, 25, 39, 100],
    stepDurationMs: 520,
  },
  {
    code: 'Phase B',
    title: 'Struktur-Optimierung',
    description: 'Identifikation von Ineffizienzen und ungenutzten Potenzialen.',
    steps: [12, 34, 61, 100],
    stepDurationMs: 560,
  },
  {
    code: 'Phase C',
    title: 'Potenzial-Vorschau',
    description: 'Berechnung der wirtschaftlichen und technischen Optimierungschancen.',
    steps: [17, 46, 73, 100],
    stepDurationMs: 610,
  },
];

// ---- Zustand ----
let analysisState = 'idle'; // 'idle' | 'running' | 'done'
let activePhaseIndex = null;
let visibleStepCounts = [0, 0, 0];
let displayedScenario = null;
let runningTimers = [];

// ---- Hilfsfunktionen ----
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function roundToNearest(value, step) {
  return Math.round(value / step) * step;
}

function formatCurrency(value) {
  return new Intl.NumberFormat('de-DE', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0,
  }).format(value);
}

function formatPercent(value) {
  return new Intl.NumberFormat('de-DE', {
    style: 'percent',
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(value);
}

function formatWholeNumber(value) {
  return new Intl.NumberFormat('de-DE', {
    maximumFractionDigits: 0,
  }).format(value);
}

// ---- Berechnungslogik (1:1 aus Original) ----
function mapDeviceState(deviceCosts) {
  if (deviceCosts === 'Ja') return 'yes';
  if (deviceCosts === 'Nein') return 'no';
  return 'unknown';
}

function mapYesNoUnknown(value) {
  if (value === 'Ja') return 'yes';
  if (value === 'Nein') return 'no';
  return 'unknown';
}

function mapAddOnIntensity(addOns) {
  const normalized = addOns.trim().toLowerCase();
  if (!normalized) return 'unknown';
  if (['keine', 'none', 'nein', 'ohne', 'no'].includes(normalized)) return 'none';
  const strongKeywords = [
    'international', 'ausland', 'multisim', 'datenboost',
    'data', 'security', 'versicherung', 'streaming', 'iot',
  ];
  const matches = strongKeywords.filter(kw => normalized.includes(kw)).length;
  const separatorCount = normalized.split(/[,+/&]/).filter(p => p.trim().length > 0).length;
  if (matches >= 3 || separatorCount >= 3) return 'many';
  return 'some';
}

function mapComplexityState(requirements) {
  if (!requirements.trim().toLowerCase()) return 'unknown';
  return 'yes';
}

function getSimCountPoints(simCount) {
  if (simCount <= 5) return 0;
  if (simCount <= 15) return 6;
  if (simCount <= 50) return 10;
  return 14;
}

function getContractAgePoints(contractAge) {
  if (contractAge <= 0) return 0;
  if (contractAge < 12) return -2;
  if (contractAge < 24) return 3;
  if (contractAge <= 36) return 8;
  return 12;
}

function getAverageCostPoints(avgCostPerSim) {
  if (avgCostPerSim < 20) return -3;
  if (avgCostPerSim <= 35) return 3;
  if (avgCostPerSim <= 50) return 8;
  return 12;
}

function getDevicePoints(deviceState) {
  if (deviceState === 'yes') return -6;
  if (deviceState === 'no') return 4;
  return 0;
}

function getAddOnPoints(addOnIntensity) {
  if (addOnIntensity === 'none') return 2;
  if (addOnIntensity === 'some') return 6;
  if (addOnIntensity === 'many') return 10;
  return 0;
}

function getFrameworkPoints(frameworkState) {
  if (frameworkState === 'yes') return -6;
  if (frameworkState === 'no') return 8;
  return 0;
}

function getComplexityPoints(complexityState) {
  if (complexityState === 'yes') return 4;
  return 0;
}

function contractAgeIsKnown(contractAge) {
  return parseFloat(contractAge.replace(',', '.')) > 0;
}

function calculateCompleteness(form) {
  const known = [
    contractAgeIsKnown(form.contractAge),
    mapDeviceState(form.deviceCosts) !== 'unknown',
    mapAddOnIntensity(form.addOns) !== 'unknown',
    mapYesNoUnknown(form.frameworkContract) !== 'unknown',
    mapComplexityState(form.requirements) !== 'unknown',
  ].filter(Boolean).length;
  return clamp(known / 5, 0, 1);
}

function calculateScenario(form) {
  const monthlyCost = Math.max(0, parseFloat(form.monthlyCost.replace(',', '.')) || 0);
  const simCount = Math.max(1, parseFloat(form.simCount.replace(',', '.')) || 1);
  const contractAge = Math.max(0, parseFloat(form.contractAge.replace(',', '.')) || 0);
  const avgCostPerSim = monthlyCost / simCount;

  const mappedDeviceState = mapDeviceState(form.deviceCosts);
  const mappedAddOnIntensity = mapAddOnIntensity(form.addOns);
  const mappedFrameworkState = mapYesNoUnknown(form.frameworkContract);
  const mappedComplexityState = mapComplexityState(form.requirements);

  let score = 35;
  score += getSimCountPoints(simCount);
  score += getContractAgePoints(contractAge);
  score += getAverageCostPoints(avgCostPerSim);
  score += getDevicePoints(mappedDeviceState);
  score += getAddOnPoints(mappedAddOnIntensity);
  score += getFrameworkPoints(mappedFrameworkState);
  score += getComplexityPoints(mappedComplexityState);
  score = clamp(score, 0, 100);

  const expectedRate = 0.15 + (score / 100) * 0.15;
  const dataCompleteness = calculateCompleteness(form);
  const width = dataCompleteness >= 0.6 ? 0.05 : 0.07;
  const lowRate = clamp(expectedRate - width, 0.15, 0.3);
  const highRate = clamp(expectedRate + width, 0.15, 0.3);

  const lowMonthlySavings = roundToNearest(monthlyCost * lowRate, 10);
  const expectedMonthlySavings = roundToNearest(monthlyCost * expectedRate, 10);
  const highMonthlySavings = roundToNearest(monthlyCost * highRate, 10);

  return {
    lowMonthlySavings,
    expectedMonthlySavings,
    highMonthlySavings,
    yearlyLowSavings: roundToNearest(lowMonthlySavings * 12, 100),
    yearlyExpectedSavings: roundToNearest(expectedMonthlySavings * 12, 100),
    yearlyHighSavings: roundToNearest(highMonthlySavings * 12, 100),
    lowRate,
    expectedRate,
    highRate,
    dataCompleteness,
  };
}

function getOverallProgress() {
  const totalSteps = ANALYSIS_PHASES.reduce((sum, p) => sum + p.steps.length, 0);
  const completedSteps = visibleStepCounts.reduce((sum, c) => sum + c, 0);
  return Math.round((completedSteps / totalSteps) * 100);
}

// ---- Formular-Werte lesen ----
function getFormValues() {
  return {
    monthlyCost: document.getElementById('monthlyCost').value,
    simCount: document.getElementById('simCount').value,
    contractAge: document.getElementById('contractAge').value,
    deviceCosts: document.getElementById('deviceCosts').value,
    addOns: document.getElementById('addOns').value,
    frameworkContract: document.getElementById('frameworkContract').value,
    requirements: document.getElementById('requirements').value,
  };
}

// ---- UI-Updates ----
function updateFactCards() {
  const form = getFormValues();
  const simCount = parseFloat(form.simCount) || 0;
  const monthlyCost = parseFloat(form.monthlyCost) || 0;

  document.getElementById('fact-sim').textContent = formatWholeNumber(simCount);
  document.getElementById('fact-cost').textContent = formatCurrency(monthlyCost);

  if (displayedScenario) {
    document.getElementById('fact-savings').textContent = formatPercent(displayedScenario.expectedRate);
  } else {
    document.getElementById('fact-savings').textContent = '0%';
  }
}

function updatePhaseCard(phaseIndex, status, progress) {
  const card = document.getElementById('phase-card-' + phaseIndex);
  const dot = document.getElementById('phase-dot-' + phaseIndex);
  const statusLabel = document.getElementById('phase-status-' + phaseIndex);
  const ringFill = document.getElementById('ring-fill-' + phaseIndex);
  const ringPercent = document.getElementById('ring-percent-' + phaseIndex);

  // Klassen zurücksetzen
  card.classList.remove('is-active', 'is-done');
  dot.classList.remove('is-active', 'is-done');
  ringFill.classList.remove('is-done');

  if (status === 'done') {
    card.classList.add('is-done');
    dot.classList.add('is-done');
    ringFill.classList.add('is-done');
    statusLabel.textContent = 'Fertig';
  } else if (status === 'active') {
    card.classList.add('is-active');
    dot.classList.add('is-active');
    statusLabel.textContent = 'Läuft';
  } else {
    statusLabel.textContent = 'Bereit';
  }

  // Ring-Fortschritt (stroke-dasharray = 100.5 für r=16)
  const circumference = 100.5;
  const offset = circumference - (progress / 100) * circumference;
  ringFill.style.strokeDashoffset = offset;
  ringPercent.textContent = progress + '%';
}

function updateProgressBars(progress) {
  document.getElementById('overall-progress-bar').style.width = progress + '%';
  document.getElementById('overall-progress-bar-2').style.width = progress + '%';
  document.getElementById('overall-progress-text').textContent = progress + '%';
  document.getElementById('overall-progress-text-2').textContent = progress + '%';
}

function updateStatusTag(state) {
  const tag = document.getElementById('status-tag');
  if (state === 'running') {
    tag.textContent = 'Analyse läuft';
    tag.style.backgroundColor = 'rgba(199, 173, 55, 0.1)';
    tag.style.borderColor = 'rgba(199, 173, 55, 0.4)';
    tag.style.color = '#8a7520';
  } else if (state === 'done') {
    tag.textContent = 'Fertig';
    tag.style.backgroundColor = '#f0fdf4';
    tag.style.borderColor = '#bbf7d0';
    tag.style.color = '#15803d';
  } else {
    tag.textContent = 'Bereit';
    tag.style.backgroundColor = '';
    tag.style.borderColor = '';
    tag.style.color = '';
  }
}

function updateMainStatusDot(isLive) {
  const dot = document.getElementById('main-status-dot');
  if (isLive) {
    dot.classList.add('is-live');
  } else {
    dot.classList.remove('is-live');
  }
}

function updateAiVisualLabel(state) {
  const label = document.getElementById('ai-visual-label');
  if (state === 'running') {
    label.textContent = 'Analyse läuft...';
  } else if (state === 'done') {
    label.textContent = 'Analyse abgeschlossen';
  } else {
    label.textContent = 'Bereit zur Analyse';
  }
}

function updateStartButton(state) {
  const btn = document.getElementById('start-btn');
  const title = document.getElementById('start-btn-title');
  const desc = document.getElementById('start-btn-desc');
  const label = document.getElementById('start-btn-label');
  const icon = document.getElementById('start-btn-icon');

  if (state === 'running') {
    btn.disabled = true;
    title.textContent = 'Die AI-Analyse läuft jetzt';
    desc.textContent = 'Der Fortschritt wird oben schrittweise durch die drei Phasen geführt.';
    label.textContent = 'Läuft';
    icon.style.animation = 'spin 1s linear infinite';
  } else {
    btn.disabled = false;
    title.textContent = 'Mit der AI-Analyse bewerten';
    desc.textContent = 'Passen Sie Eingaben an und starten Sie dann die Analyse.';
    label.textContent = 'Start';
    icon.style.animation = '';
  }

  // Formularfelder deaktivieren
  const fields = document.querySelectorAll('.field-input');
  fields.forEach(f => { f.disabled = state === 'running'; });
}

function updateResultSection(state, scenario) {
  const statusText = document.getElementById('result-status-text');
  const statusBadge = document.getElementById('result-status-badge');
  const resultWave = document.getElementById('result-wave');
  const potentialDot = document.getElementById('potential-dot');
  const potentialLiveText = document.getElementById('potential-live-text');

  if (state === 'running') {
    statusText.textContent = 'Die Analyse läuft. Nach Abschluss springen wir automatisch zur finalen Vorschau.';
    statusBadge.textContent = 'Analyse läuft';
    resultWave.classList.add('is-live');
    potentialDot.classList.add('is-live');
    potentialLiveText.textContent = 'In Analyse';
  } else if (state === 'done' && scenario) {
    statusText.textContent = 'Die Schätzung wurde aktualisiert und ist bereit für die weitere Analyse.';
    statusBadge.textContent = 'Fertig';
    resultWave.classList.remove('is-live');
    potentialDot.classList.remove('is-live');
    potentialLiveText.textContent = 'Stabilisiert';

    // Werte eintragen
    document.getElementById('potential-range').textContent =
      formatCurrency(scenario.lowMonthlySavings) + ' bis ' + formatCurrency(scenario.highMonthlySavings) + ' / Monat';
    document.getElementById('potential-expected-value').textContent =
      formatCurrency(scenario.expectedMonthlySavings);

    document.getElementById('yearly-savings').textContent =
      formatCurrency(scenario.yearlyLowSavings) + ' bis ' + formatCurrency(scenario.yearlyHighSavings);
    document.getElementById('yearly-expected').textContent =
      formatCurrency(scenario.yearlyExpectedSavings);

    document.getElementById('savings-rate').textContent =
      formatPercent(scenario.lowRate) + ' bis ' + formatPercent(scenario.highRate);

    updateFactCards();
  } else {
    statusText.textContent = 'Starten Sie die Analyse, um die Schätzung und Bewertung anzuzeigen.';
    statusBadge.textContent = 'Bereit';
    resultWave.classList.remove('is-live');
    potentialDot.classList.remove('is-live');
    potentialLiveText.textContent = 'Bereit';
  }
}

// ---- Smooth Scroll ----
function scrollToElement(elementId, block) {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.scrollIntoView({ behavior: 'smooth', block: block || 'center' });
}

// ---- Analyse starten ----
function startAnalysis() {
  if (analysisState === 'running') return;

  // Zustand zurücksetzen
  runningTimers.forEach(t => clearTimeout(t));
  runningTimers = [];
  displayedScenario = null;
  visibleStepCounts = [0, 0, 0];
  analysisState = 'running';
  activePhaseIndex = 0;

  // UI zurücksetzen
  ANALYSIS_PHASES.forEach((_, i) => updatePhaseCard(i, 'pending', 0));
  updateProgressBars(0);
  updateStatusTag('running');
  updateMainStatusDot(true);
  updateAiVisualLabel('running');
  updateStartButton('running');
  updateResultSection('running', null);

  // Zur Analyse-Sektion scrollen
  setTimeout(() => scrollToElement('analyse-tool', 'start'), 40);

  const form = getFormValues();
  const nextScenario = calculateScenario(form);
  let elapsedMs = 0;

  ANALYSIS_PHASES.forEach((phase, phaseIndex) => {
    phase.steps.forEach((stepProgress, stepIndex) => {
      elapsedMs += phase.stepDurationMs;
      const delay = elapsedMs;
      const timer = setTimeout(() => {
        activePhaseIndex = phaseIndex;

        // Vorherige Phasen als "done" markieren
        for (let i = 0; i < phaseIndex; i++) {
          const prevPhase = ANALYSIS_PHASES[i];
          const lastStep = prevPhase.steps[prevPhase.steps.length - 1];
          updatePhaseCard(i, 'done', lastStep);
        }

        // Aktuelle Phase aktualisieren
        visibleStepCounts[phaseIndex] = stepIndex + 1;
        const currentProgress = phase.steps[Math.min(stepIndex, phase.steps.length - 1)];
        updatePhaseCard(phaseIndex, 'active', currentProgress);

        // Gesamtfortschritt
        updateProgressBars(getOverallProgress());

        // Zur aktiven Phase scrollen
        const phaseCard = document.getElementById('phase-card-' + phaseIndex);
        if (phaseCard) {
          setTimeout(() => phaseCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 80);
        }
      }, delay);
      runningTimers.push(timer);
    });
  });

  // Abschluss
  const finalTimer = setTimeout(() => {
    displayedScenario = nextScenario;
    analysisState = 'done';
    activePhaseIndex = ANALYSIS_PHASES.length - 1;
    visibleStepCounts = ANALYSIS_PHASES.map(p => p.steps.length);

    // Alle Phasen als "done"
    ANALYSIS_PHASES.forEach((phase, i) => {
      updatePhaseCard(i, 'done', 100);
    });

    updateProgressBars(100);
    updateStatusTag('done');
    updateMainStatusDot(false);
    updateAiVisualLabel('done');
    updateStartButton('done');
    updateResultSection('done', displayedScenario);

    // Zum Ergebnis scrollen
    setTimeout(() => scrollToElement('ergebnis', 'center'), 260);
  }, elapsedMs + 180);
  runningTimers.push(finalTimer);
}

// ---- Kontaktformular ----
function handleContactSubmit(event) {
  event.preventDefault();
  showToast('Vielen Dank! Ihre Anfrage wurde gesendet. Wir melden uns schnellstmöglich.');
  event.target.reset();
}

function showToast(message) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}

// ---- Header Scroll-Effekt ----
function initHeaderScroll() {
  const header = document.getElementById('site-header');
  let ticking = false;

  window.addEventListener('scroll', () => {
    if (!ticking) {
      requestAnimationFrame(() => {
        if (window.scrollY > 60) {
          header.classList.add('scrolled');
        } else {
          header.classList.remove('scrolled');
        }
        ticking = false;
      });
      ticking = true;
    }
  });
}

// ---- Formular-Änderungen live aktualisieren ----
function initFormListeners() {
  const fields = ['monthlyCost', 'simCount'];
  fields.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('input', updateFactCards);
    }
  });
}

// ---- Spin-Animation für Button ----
const spinStyle = document.createElement('style');
spinStyle.textContent = '@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }';
document.head.appendChild(spinStyle);

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => {
  initHeaderScroll();
  initFormListeners();
  updateFactCards();
});
